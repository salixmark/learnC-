﻿#include <iostream>
#include <vector>
using namespace std;
int gcd(int a, int b) {
    return b == 0 ? a: gcd(b, a % b);
}
template <typename T>
class Array
{
public:
    Array(int n) { a.resize(n); }// 构造函数Array(int n)，将数组初始化为n个存储空间，建议使用vector
    void input(int n);
    T& operator [](int i) { return a[i]; }//重载下标运算符，返回数组的元素。
private:
    vector<T> a;

};
template <typename T>
void Array<T>::input(int n)//函数input(int n)，使用插入运算符<<读取数据，最多读取n个元素，但不能超过数组存储空间的上限；
{
    for (int i = 0; i < n; i++)
        cin >> a[i];
}
class Fract
{
public:
    Fract(int n=0, int m=0);//构造：传入两个参数n和m，表示n/m；分数在构造时立即转化成最简分数
    void show();
    void operator +=(Fract i);//重载+=运算符，进行分数的加法运算
    friend istream& operator >> (istream& ci, Fract& i);
private:
    int a, b;

};
istream& operator >> (istream& ci, Fract& i)
{
    ci >> i.a >> i.b;
    return ci;
}
Fract::Fract(int n, int m)
{
   int x=gcd(n, m);
   a = n/x;
   b =n==0? m: m/x;
}
void Fract::show()
{
    if (a == 0)
        cout << "0" << endl;
    else if (b == 1)
        cout << a << endl;
    else
        cout << a << "/" << b;
}//show()函数：分数输出为“a/b”或“-a/b”的形式，a、b都是无符号整数。若a为0或b为1，只输出符号和分子，不输出“/”和分母。
void Fract::operator+=(Fract i)
{
    a = a * i.b + i.a * b;
    b = b * i.b;
    int x = gcd(a, b);
    a = a/x ;
    b = a == 0 ? b : b/x;
}
int main()
{
    unsigned int n;
    cin >> n;
    Array<double> db(n);
    db.input(n);
    double dbsum(0.0);
    for (unsigned int i = 0; i < n; i++)
        dbsum += db[i];
    cout << dbsum << endl;

    cin >> n;
    Array<Fract> fr(n);
    fr.input(n);
    Fract frsum(0, 1);
    for (unsigned int i = 0; i < n; i++)
        frsum += fr[i];
    frsum.show();
}
