#ifndef PROVIDENT_AREA_H
#define PROVIDENT_AREA_H

#include <QWidget>

namespace Ui {
class provident_area;
}

class provident_area : public QWidget
{
    Q_OBJECT

public:
    explicit provident_area(QWidget *parent = nullptr);
    ~provident_area();
    void paintEvent(QPaintEvent *);

private:
    Ui::provident_area *ui;
private slots:
    void openresult();
    void enabledstartBUtton();//激活开始计算按钮
    void clear();//清空数据
};

#endif // PROVIDENT_AREA_H
