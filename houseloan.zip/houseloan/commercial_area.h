#ifndef COMMERCIAL_AREA_H
#define COMMERCIAL_AREA_H

#include <QWidget>

namespace Ui {
class commercial_area;
}

class commercial_area : public QWidget
{
    Q_OBJECT

public:
    explicit commercial_area(QWidget *parent = nullptr);
    ~commercial_area();
    void paintEvent(QPaintEvent *);


private:
    Ui::commercial_area *ui;

private slots:
    void openresult();
    void enabledstartBUtton();//激活开始计算按钮
    void clear();//清空数据
};

#endif // COMMERCIAL_AREA_H
