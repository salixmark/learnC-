#ifndef RESULT_PRINCIPAL_H
#define RESULT_PRINCIPAL_H

#include <QDialog>

namespace Ui {
class result_principal;
}

class result_principal : public QDialog
{
    Q_OBJECT

public:
    explicit result_principal(QWidget *parent = nullptr);
    ~result_principal();
    void acceptData(double price,int year,double rate);
    void acceptData(double price,double area,double mortgage,int year,double rate);
    void acceptDate(double csum,double crate, double psum, double prate, int year);
    void paintEvent(QPaintEvent *);

private:
    Ui::result_principal *ui;
};

#endif // RESULT_PRINCIPAL_H
