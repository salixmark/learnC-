#include "provident_area.h"
#include "ui_provident_area.h"
#include "result_interests.h"
#include "result_principal.h"
#include "QPainter"
provident_area::provident_area(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::provident_area)
{
    ui->setupUi(this);
    QRegExp regExp("[1-9][0-9]{0,7}");
    //正则表达式,中括号按顺序限制输入内容格式，大括号限制第二个数字的个数为0-2个
    ui->pricenumber->setValidator(new QRegExpValidator(regExp,this));
    //QRegExpValidator是正则表达式验证器（验证行输入），this指当前对话框窗口)
    ui->areanumber->setValidator(new QRegExpValidator(regExp,this));
    //上面是限制房屋面积和单价的输入格式
    ui->ratenumber->setRange(0,10);
    ui->ratenumber->setValue(6.50);
    connect(ui->start,SIGNAL(clicked()),this,SLOT(openresult()));
    this->setWindowIcon(QPixmap(":/image/house.jpg"));
    //设置窗口图标
}

provident_area::~provident_area()
{
    delete ui;
}

void provident_area::paintEvent(QPaintEvent *)
{
    QPainter paint(this);
    QPixmap mix;
    mix.load(":/image/widget.jpg");
    //让图片与窗口大小一致
    paint.drawPixmap(0,0,this->width(),this->height(),mix);
}
void provident_area::enabledstartBUtton()
{
    if(ui->pricenumber->hasAcceptableInput()&&
            ui->areanumber->hasAcceptableInput()&&
            ((ui->interest->isChecked()&&ui->principal->isChecked()==false)
            ||(ui->interest->isChecked()==false&&ui->principal->isChecked()))
            &&ui->ratenumber->hasAcceptableInput())
    {
        ui->start->setEnabled(true);
    }
    else
        ui->start->setEnabled(false);
}//只有在房屋单价、房屋面积、还款方式同时被填入规定值时，开始计算按钮才会被激活
void provident_area::openresult()
{
    QString Price = ui->pricenumber->text();
    QString Area = ui->areanumber->text();
    QString Mortgage = ui->mortgageCombo->currentText();
    QString Year = ui->yearCombo->currentText();
    //分别提取单价、面积、按揭成数、按揭年数、贷款利率的文本

    double Rate = ui->ratenumber->value();
    int year = Year.toInt();
    double mortgage = Mortgage.toDouble();
    double area = Area.toDouble();
    double price = Price.toDouble();
    //将上述提取内容分别转换成数字

    if(ui->interest->isChecked())
    {
        result_interests *result = new result_interests();
        result->acceptData(price,area,mortgage,year,Rate);
        result->show();
    }//如果是选择等额本息就打开等额本息的结果框
    else if(ui->principal->isChecked())
    {
        result_principal *result = new result_principal();
        result->acceptData(price,area,mortgage,year,Rate);
        result->show();
    }//如果是选择等额本金就打开等额本金的结果框
}
void provident_area::clear()
{
    ui->areanumber->clear();
    ui->pricenumber->clear();
    ui->ratenumber->clear();
    ui->interest->setChecked(false);
    ui->principal->setChecked(false);
}//清空面积，单价，利率的数据
