#ifndef COMMERCIAL_SUM_H
#define COMMERCIAL_SUM_H

#include <QWidget>

namespace Ui {
class commercial_sum;
}

class commercial_sum : public QWidget
{
    Q_OBJECT

public:
    explicit commercial_sum(QWidget *parent = nullptr);
    ~commercial_sum();
    void paintEvent(QPaintEvent *);

private slots:
    void enabledstartBUtton();
    void clear();
    void openresult();
private:
    Ui::commercial_sum *ui;
};

#endif // COMMERCIAL_SUM_H
