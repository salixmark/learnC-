#include "mix.h"
#include "ui_mix.h"
#include "result_interests.h"
#include "result_principal.h"
#include "QPainter"
mix::mix(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::mix)
{
    ui->setupUi(this);
    QRegExp regExp("[1-9][0-9]{0,7}");
    //正则表达式,中括号按顺序限制输入内容格式，大括号限制第二个数字的个数为0-2个
    ui->commercial_sum->setValidator(new QRegExpValidator(regExp,this));
    //QRegExpValidator是正则表达式验证器（验证行输入），this指当前对话框窗口)
    ui->provident_sum->setValidator(new QRegExpValidator(regExp,this));
    //上面是限制公积金贷款额、商业贷款额的输入格式
    ui->commercial_rate->setRange(0,10);//设置范围0-10
    ui->commercial_rate->setValue(6.50);//设置初值6.5
    ui->provident_rate->setRange(0,10);
    ui->provident_rate->setValue(6.50);
}

mix::~mix()
{
    delete ui;
}

void mix::paintEvent(QPaintEvent *)
{
    QPainter paint(this);
    QPixmap mix;
    mix.load(":/image/back.jpg");
    //让图片与窗口大小一致
    paint.drawPixmap(0,0,this->width(),this->height(),mix);//设置背景图片
}

void mix::enabledstartBUtton()
{
    if(ui->commercial_sum->hasAcceptableInput()&&
            ui->provident_sum->hasAcceptableInput()&&
            ((ui->interests->isChecked()&&ui->principal->isChecked()==false)||
             (ui->interests->isChecked()==false&&ui->principal->isChecked())))
    {
        ui->start->setEnabled(true);
    }
    else
        ui->start->setEnabled(false);
}//只有当商业贷款额，公积金贷款额，还款方式都被填入有效内容，按钮才会被激活

void mix::clear()
{
    ui->commercial_sum->clear();
    ui->provident_sum->clear();
    ui->interests->setChecked(false);
    ui->principal->setChecked(false);
    ui->commercial_rate->clear();
    ui->provident_rate->clear();
}

void mix::openresult()
{
    QString csum = ui->commercial_sum->text();
    QString psum = ui->provident_sum->text();
    QString Year = ui->year->currentText();
    //分别提取商业贷款额、公积金贷款额、按揭年数的文本

    double crate = ui->commercial_rate->value();//商代利率
    double prate = ui->provident_rate->value();//公贷利率
    int year = Year.toInt();//按揭年数
    double Csum = csum.toDouble();//商代额
    double Psum = psum.toDouble();//公贷额
    //将上述提取内容分别转换成数字

    if(ui->interests->isChecked())
    {
        result_interests *result = new result_interests();
        result->acceptDate(Csum,crate, Psum,prate, year);
        result->show();
    }//如果是选择等额本息就打开等额本息的结果框
    else if(ui->principal->isChecked())
    {
        result_principal *result = new result_principal();
        result->acceptDate(Csum,crate, Psum,prate, year);
        result->show();
    }//如果是选择等额本金就打开等额本金的结果框
}//清空商业贷款额、利率，公积金贷款额、利率，贷款方式
