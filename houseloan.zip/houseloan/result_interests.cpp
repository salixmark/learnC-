#include "result_interests.h"
#include "ui_result_interests.h"
#include <QtCore/qmath.h>
#include "QPainter"
result_interests::result_interests(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::result_interests)
{
    ui->setupUi(this);
    this->setWindowIcon(QPixmap(":/image/house.jpg"));
    //设置窗口图标
}

result_interests::~result_interests()
{
    delete ui;
}
void result_interests::acceptData(double price, double area, double mortgage, int year, double rate)
{
    double firstpay;//首付
    double monthlypay;//每月月供
    double totalloan;//贷款总额
    double interestspay;//支付利息
    double totalpay;//还款总额
    int totalmonth;//还款月数
    double monthrate = rate/12/100;//月利率

    firstpay = price*area*(1-mortgage/10);
    //首付=房屋单价×面积×（1-按揭成数）
    totalloan = price*area*mortgage/10;
    //贷款总额=房屋单价×面积×按揭成数
    totalmonth = year*12;
    //还款月数=按揭年数×12
    monthlypay = totalloan*monthrate*powl(1+monthrate,totalmonth)/(powl(1+monthrate,totalmonth)-1);
    //计算月供=总贷款额×月利率×（1+月利率）^还款次数/[(1+月利率）^还款次数-1]
    totalpay = monthlypay*totalmonth;
    //还款总额=月供×还款次数
    interestspay = totalpay - totalloan;
    //总利息=还款总额-贷款总额；

    QString Firstpay = QString::number((int)firstpay);
    QString Monthlypay = QString::number((int)monthlypay);
    QString Totalloan = QString::number((int)totalloan);
    QString Totalpay = QString::number((int)totalpay);
    QString Interestspay = QString::number((int)interestspay);
    QString Totalmonth = QString::number((int)totalmonth);
    ui->first_pay->setText(Firstpay);
    ui->monthly_pay->setText(Monthlypay);
    ui->total_loan->setText(Totalloan);
    ui->interests->setText(Interestspay);
    ui->total_payment->setText(Totalpay);
    ui->month->setText(Totalmonth);

}

void result_interests::acceptData(double price, int year, double rate)
{
    double totalloan = price*10000;//总贷款额
    double monthlypay;//月供
    double interest;//利息
    double totalpay;//还款总额
    double totalmonth;//还款月数
    double monthrate = rate/12/100;//月利率

    totalmonth = year*12;//总还款月数
    monthlypay = totalloan*monthrate*powl(1+monthrate,totalmonth)/(powl(1+monthrate,totalmonth)-1);
    //计算月供=总贷款额×月利率×（1+月利率）^还款次数/[(1+月利率）^还款次数-1]
    totalpay = monthlypay*totalmonth;
    //还款总额=月供×还款次数
    interest = totalpay - totalloan;
    //总利息=还款总额-贷款总额；

    QString Monthlypay = QString::number((int)monthlypay);
    QString Totalloan = QString::number((int)totalloan);
    QString Totalpay = QString::number((int)totalpay);
    QString Interestspay = QString::number((int)interest);
    QString Totalmonth = QString::number((int)totalmonth);
    //将上述数据转换成字符串

    ui->first_pay->hide();
    ui->label->hide();
    ui->label_8->hide();
    //隐藏首付栏
    ui->monthly_pay->setText(Monthlypay);
    ui->total_loan->setText(Totalloan);
    ui->interests->setText(Interestspay);
    ui->total_payment->setText(Totalpay);
    ui->month->setText(Totalmonth);
    //显示计算结果
}

void result_interests::acceptDate(double csum, double crate, double psum, double prate, int year)
{
    double totalloan = (csum+psum)*10000;//总贷款额
    double monthlypay;//月供
    double interest;//利息
    double totalpay;//还款总额
    double totalmonth;//还款月数
    double cmonthrate = crate/12/100;//商贷月利率
    double pmonthrate = prate/12/100;//公贷月利率

    totalmonth = year*12;//总还款月数
    monthlypay = csum*10000*cmonthrate*powl(1+cmonthrate,totalmonth)/(powl(1+cmonthrate,totalmonth)-1)+
            psum*10000*pmonthrate*powl(1+pmonthrate,totalmonth)/(powl(1+pmonthrate,totalmonth)-1);
    //月供=商贷月供+公贷月供
    totalpay = monthlypay*totalmonth;
    //还款总额=月供×还款次数
    interest = totalpay - totalloan;
    //总利息=还款总额-贷款总额；
    QString Monthlypay = QString::number((int)monthlypay);
    QString Totalloan = QString::number((int)totalloan);
    QString Totalpay = QString::number((int)totalpay);
    QString Interestspay = QString::number((int)interest);
    QString Totalmonth = QString::number((int)totalmonth);
    //将上述数据转换成字符串

    ui->first_pay->hide();
    ui->label->hide();
    ui->label_8->hide();
    //隐藏首付栏
    ui->monthly_pay->setText(Monthlypay);
    ui->total_loan->setText(Totalloan);
    ui->interests->setText(Interestspay);
    ui->total_payment->setText(Totalpay);
    ui->month->setText(Totalmonth);
}

void result_interests::paintEvent(QPaintEvent *)
{
    QPainter paint(this);
    QPixmap mix;
    mix.load(":/image/back.jpg");
    //让图片与窗口大小一致
    paint.drawPixmap(0,0,this->width(),this->height(),mix);
}
