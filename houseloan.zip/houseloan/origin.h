#ifndef ORIGIN_H
#define ORIGIN_H

#include <QWidget>

namespace Ui {
class origin;
}

class origin : public QWidget
{
    Q_OBJECT

public:
    explicit origin(QWidget *parent = nullptr);
    ~origin();
    void paintEvent(QPaintEvent *);

private:
    Ui::origin *ui;

private slots:
    void opendialog();//打开相应对话框
    void enabledokBUtton();//激活确认按钮
};

#endif // ORIGIN_H
