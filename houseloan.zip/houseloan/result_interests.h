#ifndef RESULT_INTERESTS_H
#define RESULT_INTERESTS_H

#include <QDialog>

namespace Ui {
class result_interests;
}

class result_interests : public QDialog
{
    Q_OBJECT

public:
    explicit result_interests(QWidget *parent = nullptr);
    ~result_interests();
    void acceptData(double price,double area,double mortgage,int year,double rate);
    void acceptData(double price,int year,double rate);
    void acceptDate(double csum,double crate, double psum, double prate, int year);
    void paintEvent(QPaintEvent *);

private:
    Ui::result_interests *ui;
};

#endif // RESULT_INTERESTS_H
