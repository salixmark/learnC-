#ifndef PROVIDENT_SUM_H
#define PROVIDENT_SUM_H

#include <QWidget>

namespace Ui {
class provident_sum;
}

class provident_sum : public QWidget
{
    Q_OBJECT

public:
    explicit provident_sum(QWidget *parent = nullptr);
    ~provident_sum();

private:
    Ui::provident_sum *ui;
private slots:
    void enabledstartBUtton();
    void clear();
    void openresult();
};

#endif // PROVIDENT_SUM_H
