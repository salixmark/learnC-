#ifndef MIX_H
#define MIX_H

#include <QWidget>

namespace Ui {
class mix;
}

class mix : public QWidget
{
    Q_OBJECT

public:
    explicit mix(QWidget *parent = nullptr);
    ~mix();
    void paintEvent(QPaintEvent *);

private:
    Ui::mix *ui;
private slots:
    void enabledstartBUtton();//激活开始计算按钮
    void clear();//清空数据
    void openresult();
    //打开对应结果框
};

#endif // MIX_H
