#include "result_principal.h"
#include "ui_result_principal.h"
#include "QPainter"
result_principal::result_principal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::result_principal)
{
    ui->setupUi(this);
    this->setWindowIcon(QPixmap(":/image/house.jpg"));
    //设置窗口图标
}

result_principal::~result_principal()
{
    delete ui;
}

void result_principal::acceptData(double price, int year, double rate)
{
    double totalloan = price*10000;//总贷款额
    double monthlypay;//首月月供
    double interest;//利息
    double totalpay;//还款总额
    double totalmonth;//还款月数
    double monthrate = rate/12/100;//月利率
    double decrease;//每月递减
    double monthpay;//每月本金

    totalmonth = year*12;
    //还款月数=按揭年数×12
    monthpay = totalloan/totalmonth;
    //每月本金=贷款总额/还款月数
    monthlypay = monthpay+totalloan*monthrate;
    //首月月供=每月本金+第一个月的利息（贷款总额*月利率）
    decrease = monthpay*monthrate;
    //每月递减=每月本金×月利率；
    interest = totalloan*monthrate*(totalmonth+1)/2;
    //支付利息=贷款总额×月利率×（还款月数+1）/2
    totalpay = interest + totalloan;
    //还款总额= 支付利息+贷款总额

    QString Monthlypay = QString::number((int)monthlypay);//首月月供
    QString Totalloan = QString::number((int)totalloan);//贷款总额
    QString Totalpay = QString::number((int)totalpay);//还款总额
    QString Interestspay = QString::number((int)interest);//支付利息
    QString Totalmonth = QString::number(totalmonth);//还款月数
    QString Decrease = QString::number((int)decrease);//每月递减

    ui->first_pay->hide();
    ui->label->hide();
    ui->label_8->hide();
    //隐藏首付栏
    ui->monthly_pay->setText(Monthlypay);
    ui->total_loan->setText(Totalloan);
    ui->interests->setText(Interestspay);
    ui->total_payment->setText(Totalpay);
    ui->total_month->setText(Totalmonth);
    ui->lineEdit->setText(Decrease);
    //显示数据
}

void result_principal::acceptData(double price, double area, double mortgage, int year, double rate)
{
    double firstpay;//首付
    double monthlypay;//首月月供
    double decrease;//每月递减
    double totalloan;//贷款总额
    double interestspay;//支付利息
    double totalpay;//还款总额
    int totalmonth;//还款月数
    double monthrate = rate/12/100;//月利率
    double monthpay;//每月本金

    firstpay = price*area*(1-mortgage/10);
    //首付=房屋单价×面积×（1-按揭成数）
    totalloan = price*area*mortgage/10;
    //贷款总额=房屋单价×面积×按揭成数
    totalmonth = year*12;
    //还款月数=按揭年数×12
    monthpay = totalloan/totalmonth;
    //每月本金=贷款总额/还款月数
    monthlypay = monthpay+totalloan*monthrate;
    //首月月供=每月本金+第一个月的利息（贷款总额*月利率）
    decrease = monthpay*monthrate;
    //每月递减=每月本金×月利率；
    interestspay = totalloan*monthrate*(totalmonth+1)/2;
    //支付利息=贷款总额×月利率×（还款月数+1）/2
    totalpay = interestspay + totalloan;
    //还款总额= 支付利息+贷款总额

    QString Firstpay = QString::number((int)firstpay);//首付
    QString Monthlypay = QString::number((int)monthlypay);//首月月供
    QString Totalloan = QString::number((int)totalloan);//贷款总额
    QString Totalpay = QString::number((int)totalpay);//还款总额
    QString Interestspay = QString::number((int)interestspay);//支付利息
    QString Totalmonth = QString::number(totalmonth);//还款月数
    QString Decrease = QString::number((int)decrease);//每月递减
    ui->first_pay->setText(Firstpay);
    ui->monthly_pay->setText(Monthlypay);
    ui->total_loan->setText(Totalloan);
    ui->interests->setText(Interestspay);
    ui->total_payment->setText(Totalpay);
    ui->total_month->setText(Totalmonth);
    ui->lineEdit->setText(Decrease);
    //显示数据
}

void result_principal::acceptDate(double csum, double crate, double psum, double prate, int year)
{
    int totalloan = (csum+psum)*10000;//总贷款额
    double monthlypay;//首月月供
    double interest;//利息
    double totalpay;//还款总额
    double totalmonth;//还款月数
    long double cmonthrate = crate/12/100;//商贷月利率
    long double pmonthrate = prate/12/100;//公贷月利率
    double decrease;//每月递减
    double monthpay;//每月本金
    double cmonthpay;//商贷每月本金
    double pmonthpay;//公贷每月本金

    totalmonth = year*12;
    //还款月数=按揭年数×12
    monthpay = totalloan/totalmonth;
    //每月本金=贷款总额/还款月数
    cmonthpay = csum*10000/totalmonth;
    //商贷每月本金=商贷额/还款月数
    pmonthpay = psum*10000/totalmonth;
    //公贷每月本金=公贷额/还款月数
    monthlypay = monthpay+csum*10000*cmonthrate+psum*10000*pmonthrate;
    //首月月供=每月本金+第一个月的利息（商业贷款总额*月利率+公积金贷款总额*月利率）
    decrease = cmonthpay*cmonthrate+pmonthpay*pmonthrate;
    //每月递减=每月本金×月利率；
    interest = csum*10000*cmonthrate*(totalmonth+1)/2+psum*10000*pmonthrate*(totalmonth+1)/2;
    //支付利息=贷款总额×月利率×（还款月数+1）/2
    totalpay = interest + totalloan;
    //还款总额= 支付利息+贷款总额
    QString Monthlypay = QString::number((int)monthlypay);//首月月供
    QString Totalloan = QString::number((int)totalloan);//贷款总额
    QString Totalpay = QString::number((int)totalpay);//还款总额
    QString Interestspay = QString::number((int)interest);//支付利息
    QString Totalmonth = QString::number(totalmonth);//还款月数
    QString Decrease = QString::number((int)decrease);//每月递减

    ui->first_pay->hide();
    ui->label->hide();
    ui->label_8->hide();
    //隐藏首付栏
    ui->monthly_pay->setText(Monthlypay);
    ui->total_loan->setText(Totalloan);
    ui->interests->setText(Interestspay);
    ui->total_payment->setText(Totalpay);
    ui->total_month->setText(Totalmonth);
    ui->lineEdit->setText(Decrease);
    //显示数据
}

void result_principal::paintEvent(QPaintEvent *)
{
    QPainter paint(this);
    QPixmap mix;
    mix.load(":/image/back.jpg");
    //让图片与窗口大小一致
    paint.drawPixmap(0,0,this->width(),this->height(),mix);
}
