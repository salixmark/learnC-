#include "commercial_sum.h"
#include "ui_commercial_sum.h"
#include "result_interests.h"
#include "result_principal.h"
#include "QPainter"
commercial_sum::commercial_sum(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::commercial_sum)
{
    ui->setupUi(this);
    QRegExp regExp("[1-9][0-9]{0,8}");
    //正则表达式,中括号按顺序限制输入内容格式，大括号限制第二个数字的个数为0-2个
    ui->lineEdit->setValidator(new QRegExpValidator(regExp,this));
    //限制贷款总额文本框的输入格式
    //QRegExpValidator是正则表达式验证器（验证行输入），this指当前对话框窗口)
    ui->ratenumber->setRange(0,10);
    ui->ratenumber->setValue(6.50);
    this->setWindowIcon(QPixmap(":/image/house.jpg"));
    //设置窗口图标
}

commercial_sum::~commercial_sum()
{
    delete ui;
}

void commercial_sum::paintEvent(QPaintEvent *)
{
    QPainter paint(this);
    QPixmap mix;
    mix.load(":/image/back.jpg");
    //让图片与窗口大小一致
    paint.drawPixmap(0,0,this->width(),this->height(),mix);
}
void commercial_sum::enabledstartBUtton()
{

    if(ui->lineEdit->hasAcceptableInput()&&
       ((ui->interest->isChecked()&&ui->principal->isChecked()==false)||
        (ui->principal->isChecked()&&ui->interest->isChecked()==false))
        &&ui->ratenumber->hasAcceptableInput())
    {
        ui->start->setEnabled(true);
    }
    else
    {
        ui->start->setEnabled(false);
    }
}//当输入正确格式的贷款总额，并且选择了还款方式后激活按钮
void commercial_sum::clear()
{
    ui->lineEdit->clear();
    ui->ratenumber->clear();
    ui->interest->setChecked(false);
    ui->principal->setChecked(false);
}//清除贷款总额和贷款利率,取消还款方式的勾选状态
void commercial_sum::openresult()
{
    QString Price = ui->lineEdit->text();
    QString Year = ui->yearCombo->currentText();
    //分别提取贷款总额、按揭年数、贷款利率的文本

    double Rate = ui->ratenumber->value();
    int year = Year.toInt();
    double price = Price.toDouble();
    //将上述提取内容分别转换成数字

    if(ui->interest->isChecked())
    {
        result_interests *result = new result_interests();
        result->acceptData(price,year,Rate);
        result->show();
    }//如果是选择等额本息就打开等额本息的结果框
    else if(ui->principal->isChecked())
    {
        result_principal *result = new result_principal();
        result->acceptData(price,year,Rate);
        result->show();
    }//如果是选择等额本金就打开等额本金的结果框
}
