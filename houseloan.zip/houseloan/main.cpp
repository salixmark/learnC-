#include "origin.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    origin *show = new origin();
    show->show();
    return a.exec();
}
