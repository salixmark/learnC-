#include "origin.h"
#include "ui_origin.h"
#include "commercial_area.h"
#include "commercial_sum.h"
#include "provident_area.h"
#include "provident_sum.h"
#include "mix.h"
origin::origin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::origin)
{
    ui->setupUi(this);

    QButtonGroup* pButtonGroup1 = new QButtonGroup(this);
    QButtonGroup* pButtonGroup2 = new QButtonGroup(this);
    pButtonGroup1->addButton(ui->commercial,1);
    pButtonGroup1->addButton(ui->provident, 2);
    pButtonGroup1->addButton(ui->mix, 3);
    pButtonGroup2->addButton(ui->area_2, 1);
    pButtonGroup2->addButton(ui->sum, 2);
    //分别设置贷款类别和计算方式为单选
}

origin::~origin()
{
    delete ui;
}
void origin::enabledokBUtton()
{
    if((ui->commercial->isChecked())
        &&(ui->area_2->isChecked()||ui->sum->isChecked()))
    {
        ui->ok->setEnabled(true);
    }//如果商业贷款及其贷款方式都被勾选
    else if((ui->provident->isChecked())
            &&(ui->area_2->isChecked()||ui->sum->isChecked()))
    {
        ui->ok->setEnabled(true);
    }//如果公积金贷款及其贷款方式都被选择 就激活按钮
    else if(ui->mix->isChecked()&&ui->area_2->isChecked()==false&&ui->sum->isChecked())
    {
        ui->ok->setEnabled(true);//如果仅组合型贷款被勾选 也激活按钮
    }
    else
    {
        ui->ok->setEnabled(false);
    }//以上条件都不满足则不激活
}//激活确认按钮
void origin::opendialog()
{
    if(ui->commercial->isChecked()&&ui->area_2->isChecked())
    {
        commercial_area *area=new commercial_area();
        area->show();
    }//打开商业贷款-用面积单价计算的对话框

    else if(ui->commercial->isChecked()&&ui->sum->isChecked())
    {
        commercial_sum *sum=new commercial_sum();
        sum->show();
    }//打开商业贷款-用贷款总额计算的对话框

    else if(ui->provident->isChecked()&&ui->area_2->isChecked())
    {
        provident_area *area=new provident_area();
        area->show();
    }//打开公积金贷款-用面积单价计算的对话框

    else if(ui->provident->isChecked()&&ui->sum->isChecked())
    {
        provident_sum *sum=new provident_sum();
        sum->show();
    }//打开公积金贷款-用贷款总额计算的对话框

    else if(ui->mix->isChecked())
    {
        mix *loan=new mix();
        loan->show();
    }//打开混合贷款对话框
}//打开相应对话框


