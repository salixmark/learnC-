﻿#include <iostream>
#include <iomanip>
using namespace std;
template <typename T>
struct node
{
    T data;
    node<T>* next;
};
template <typename T>
class linkedList
{
public:
    linkedList();
    virtual ~linkedList();
    void insert(T value);
    bool initiate();
    bool isEmpty();
    bool remove(int pos, T& value);
    void print();
    int Length();//返回单链表长度。如果是单链表为空，则返回-1
private:
    node<T>* head;
    int len;
};
template <typename T>
linkedList<T>::linkedList()
{
    head = NULL;
    len = 0;
}//构造函数
template <typename T>
linkedList<T>::~linkedList()
{
    node<T>* p;
    while (head != NULL)
    {
        p = head;
        head = head->next;
        delete p;
    }
}//析构函数，注意要删除链表中所有节点的资源
template <typename T>
bool linkedList<T>::initiate()
{
    head = new node<T>;
    head->next = NULL;
    if (head == NULL)
    {
        return false;
    }
    else
        return true;
}//初始化单链表，使用new操作创建头结点。如果创建失败，则返回false，否则返回true
template <typename T>
void linkedList<T>::insert(T value)
{
    node<T>* p = head;
    while (p->next != NULL) {
        p = p->next;
    }
    p->next = new node<T>;
    p = p->next;
    p->data = value;
    p->next = NULL;
    len++;
}//，插入节点，警告：必须初始化才能使用！
template <typename T>
bool linkedList<T>::isEmpty()
{
    if (head == NULL)
        return true;
    else
        return false;
}//判断单链表是否为空
template <typename T>
bool linkedList<T>::remove(int pos, T& value)
{
    node<T>* p = head;
    node<T>* q = head;
    if (head == NULL)
    {
        cout << "linkedList is NULL,failed" << endl;
        return false;
    }
    if (pos > len)
    {
        cout << "pos > len, failed" << endl;
        return false;
    }
    while (pos > 0)
    {
        q = p;
        p = p->next;
        pos--;
    }
    if (p->data <= 0)
    {
        cout << "pos <= 0, failed" << endl;
        return false;
    }
    value = p->data;
    q->next = p->next;
    delete p;
    len--;
    return true;
}//删除单链表中第pos个元素结点，并将删除的节点的值存在value中。
    //注意：如果链表为空、删除位置大于链表长度、以及删除位置为0的情况，需要终止删除并输出相应信息
template <typename T>
int linkedList<T>::Length()
{
    if (len > 0)
        return len;
    else
        return -1;
}
template <typename T>
void linkedList<T>::print()
{
    if (isEmpty())
    {
        cout << "Empty" << endl;
        return;
    }
    node<T>* tmp = head->next;
    while (tmp)
    {
        cout << tmp->data << " ";
        tmp = tmp->next;
    }
    cout << endl;
}//顺序打印单链表，如果是单链表为空，则输出 Empty


int main(int argc, char* argv[])

{

    linkedList<int> L1;

    int n;

    int val;

    //初始化链表

    if (!L1.initiate())

        return 0;



    cin >> n;//输入链表中数据个数

    for (int i = 0; i < n; i++) //输入n个数，并插入链表

    {

        cin >> val;

        L1.insert(val);

    }

    cout << "Origin Length：" << L1.Length() << endl;//输出链表长度

    cout << "data：";

    L1.print();//打印链表



    cin >> n;//输入需要删除的数据的位置

    if (L1.remove(n, val))

    {

        //删除位置n的数据，并将删除的数据值放在val中

        cout << "Delete the data at position(" << n << "):" << val << endl;

        cout << "New Length：" << L1.Length() << endl;//输出链表长度

        cout << "data：";

        L1.print();//打印链表

    }

    return 0;

}

